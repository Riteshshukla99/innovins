<?php  
include 'get_db_connection.php';
if(isset($_GET['deleteid'])){
    $id=$_GET['deleteid'];

    $sql="delete from productmaster where id=$id";
    $result=mysqli_query($conn,$sql);
    if($result){
        header("location:show.php");
    }else{
        die(mysqli_error($conn));
    }

}
<?php
include 'get_db_connection.php';

$id = $_GET['updateid'];

// Fetch existing product details
$sql = "SELECT * FROM productmaster WHERE id = $id";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

$name        = $row['name'];
$description = $row['description'];
$price       = $row['price'];

if (isset($_POST['submit'])) {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price = $_POST['price'];

    $updateddate = date('Y-m-d H:i:s');
    $admin = 'Admin'; 
    
    // Check if the product name already exists
    $query_check = "SELECT * FROM productmaster WHERE name = '$name' AND id != '$id'";
    $query_run_check = mysqli_query($conn, $query_check);

    if (mysqli_num_rows($query_run_check) > 0) {
        $_SESSION['status_failed'] = "Product: $name already exists.";
        header('Location: product_update.php?updateid=' . $id);
        exit;
    } else {
    

        $sql1 = "UPDATE productmaster SET name = '$name',description = '$description', price = '$price', 
                                        updateddate = '$updateddate',updatedby = '$admin' WHERE id = $id";

        $product_updatequery_run = mysqli_query($conn, $sql1);

        if ($product_updatequery_run) {
            $_SESSION['status_success'] = "Product details updated successfully.";
            header('Location: show.php');
            exit;
        } else {
            $_SESSION['status_failed'] = "Product update failed. Please try again.";
            header('Location: product_update.php?updateid=' . $id);
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Update Product</title>
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center">Update Product</h2>
        <?php
        session_start();
        if (isset($_SESSION['status_success'])) {
            echo '<div class="alert alert-success">' . $_SESSION['status_success'] . '</div>';
            unset($_SESSION['status_success']);
        }
        if (isset($_SESSION['status_failed'])) {
            echo '<div class="alert alert-danger">' . $_SESSION['status_failed'] . '</div>';
            unset($_SESSION['status_failed']);
        }
        ?>

        <!-- Update form -->
        <form action="" method="POST">
            <div class="row g-3">
                <div class="form-group">
                    <label class="form-label">Product Name</label>
                    <input type="text" name="name" class="form-control" value="<?php echo $name; ?>" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="4" required><?php echo $description; ?></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label">Price</label>
                    <input type="number" name="price" class="form-control" value="<?php echo $price; ?>" required>
                </div>
            </div><br>

                <button type="submit" name="submit" class="btn btn-primary">Update</button>
            </div>
        </form>
    </div>
</body>
</html>

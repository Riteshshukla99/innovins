<?php 

$servername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName     = "crud2";

$conn = mysqli_connect($servername, $dbUsername, $dbPassword, $dbName);

?>
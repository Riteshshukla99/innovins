<?php
session_start();

if(isset($_POST['ADD_TO_CART'])){
    $product_id = $_POST['product_id'];
    if(!isset($_SESSION['cart']))
    {
        $_SESSION['cart'] = [];
    }
     if (!in_array($product_id, $_SESSION['cart'])){
        $_SESSION['cart'][] = $product_id;
        echo "Product add to cart!";
     }
     else{
        echo "Product is already in the cart!";
     }
     }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title> ADD TO cart </title>
    </head>
    <body>
        <h1>Product List</h1>
        <form method="POST">
            <p>product 1<button type="submit" name="add_to_cart" value="1"> Add To Cart </button></p>
                <input type="hidden" name="product_id" value="1">
    </form>

    <ul>
        <?php
        if(isset($_SESSION['cart']) && ! empty($_SESSION['cart'])) {
            foreach ($_SESSION['cart'] as $item) {
                echo "<li>Product ID: " . $item . "</li>";
            }
        } else {
            echo "<p>Your cart is empty.</p>";
        }
        ?>
        </ul>
    </body>
    </html>


<?php
$first =0;
$second =1;

echo $first. "" . $second."";


for($i= 3; $i <=10; $i++)
    { $third = $first + $second;

    echo $third . ""; $first = $second;
    $second =$third;}

?>